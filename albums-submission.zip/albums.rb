#
# CS 2040
# Lab 2
# Spring 2023
# Dr. Hasker
# Author: Cecelia Henson
#
class Artist
  def initialize(name)
    @name = name
    @tracks = []
  end

  def total_time
    total_time = @tracks.map {|x| x.get_length}
    return total_time.sum
  end

  def average_time
    avg_time = @tracks.map {|x| x.get_length}
    return avg_time.sum / @tracks.size.to_f
  end

  def longest_track_title
    time = 0
    title = ""
    @tracks.each do|x| 
      if x.get_length > time 
        time = x.get_length
        title = x.get_album_name 
      end
    end
    return title
  end

  def addlist(track)
    @tracks = @tracks.push(track)
  end

end

class Album
  def initialize(album_title, date_produced, tracks)
    @album_title = album_title
    @date_produced = date_produced
    @tracks = tracks
  end
  
  def get_album_name
    @album_title
  end

  def total_time
    total_time = @tracks.map {|x| x.get_length}
    return total_time.sum
  end

  def average_time
    avg_time = @tracks.map {|x| x.get_length}
    return avg_time.sum / @tracks.size.to_f
  end

  def longest_track_title
    time = 0
    title = ""
    @tracks.each do|x| 
      if x.get_length > time 
        time = x.get_length
        title = x.get_album_name 
      end
    end
    return title
  end

  def addlist(track)
    @tracks = @tracks.push(track)
  end
end



class Track
  def initialize(album_title, track_length)
    @album_title = album_title
    @track_length = track_length.to_i
  end

  def get_album_name
    @album_title
  end

  def get_length
    @track_length
  end
end



def process_queries(all_albums, all_artists)
  # both are hash tables to the corresponding objects
  while (cmd_line = gets)
    type, operation, name = cmd_line.strip.split(',')
    print name + ": "
    if type == 'album'
      album = all_albums[name]
      if album == nil
        puts "ERROR: no such album"
      elsif operation == 'total'
        puts "#{album.total_time} total seconds for all tracks"
      elsif operation == 'average'
        puts "#{album.average_time.round(1)} average seconds per track"
      elsif operation == 'longest'
        puts "#{album.longest_track_title} is the album's longest track"
      else
        puts "ERROR: no such operation"
      end
    else # type == artist
      artist = all_artists[name]
      if artist == nil
        puts "ERROR: no such artist"
      elsif operation == 'total'
        puts "#{artist.total_time} total seconds for all tracks"
      elsif operation == 'average'
        puts "#{artist.average_time.round(1)} average seconds per track"
      elsif operation == 'longest'
        puts "#{artist.longest_track_title} is the artist's longest track"
      else
        puts "ERROR: no such operation"
      end
    end
  end
end

#filtering the artist tracks
def filter(all_artists, artist_names, track)
  artist_names.each do |x|
    artist = Artist.new(x.strip)
    if all_artists.has_key?(x.strip)
      artist_track = all_artists[x.strip]
      artist_track.addlist(track)          
    else
      all_artists.store(x.strip, artist)
      artist_track = all_artists[x.strip]
      artist_track.addlist(track)
    end
  end
end


def main
  cmd_line = ""
  all_albums = {}
  all_artists = {}

  while cmd_line != 'QUERIES'

    cmd_line = gets.chomp 

    next unless cmd_line == "ALBUM"

    album_title = gets.chomp.strip
    date_produced = gets.chomp
    second_cmd = gets
    tracks = []

    while second_cmd.chomp != "END"

      track_line = second_cmd.strip.split(',')
      input1 = track_line[0].strip
      input2 = track_line[1].strip

      track = Track.new(input1,input2)
      tracks.append(track)
      artist_names = track_line.drop(2)

      filter(all_artists, artist_names, track)

      second_cmd = gets

    end
    #storing album
    album = Album.new(album_title, date_produced, tracks)
    album_name = album.get_album_name
    all_albums.store(album_name, album)
    
  end
  puts "Read #{all_albums.size} albums with #{all_artists.size} artists"
  process_queries(all_albums, all_artists)
end
 

if $0 == __FILE__
  main
end
