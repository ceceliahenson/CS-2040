//============================================================================
// Name        : lab3hist.cpp
// Author      : Cecelia Henson
// Version     :
// Description : 
//============================================================================
#include <iostream>
#include <iomanip>
using namespace std;

int greatestFrequency(int array[], int start_index, int stop_index);

int axisWidth(int array[], int start_index, int stop_index);

void drawHorizontalAxis(int axisWidth);

void labelHorizontalAxis(int axisWidth);

void drawCount(int value, int quantity);

void arrayValues(int array[], int start_index, int end_index);

void drawValues(int array[], int start_index, int end_index);

void histogram(int array[], int start_index, int end_index);

int startRange();

int endRange();



int main(){
    int start_index = startRange();
    int end_index = endRange();

    int array[end_index - start_index + 1] = {0};

    arrayValues(array, start_index, end_index);
    histogram(array, start_index, end_index);

    return 0;
}

int greatestFrequency(int array[], int start_index, int stop_index){
    int frequentNumber = 0;
    for(int i = 0; i <= stop_index - start_index; i++){
        if(array[i] > frequentNumber){
            frequentNumber = array[i];
        }
    }
    return frequentNumber;

}

int startRange(){
    int start_index;
    cin >> start_index;
    return start_index;
}

int endRange(){
    int end_index;
    cin >> end_index;
    return end_index;
}


int axisWidth(int array[], int start_index, int stop_index){
    int axisWidth;
    int frequency = greatestFrequency(array, start_index, stop_index);

    if(frequency < 10){
        axisWidth = 10;
    }else if(frequency % 10 == 0){
        axisWidth = frequency;
    }else{
        axisWidth = (frequency + 10) - (frequency % 10);
    }
    return axisWidth;
}

void drawHorizontalAxis(int axisWidth){
    int width = axisWidth;
    cout << "    +";
    for(int i=0; i < width / 10; i++) {
        cout << "----+----+";
    }
    cout << endl;
}

void labelHorizontalAxis(int axisWidth){
    cout << "    ";
    for(int i = 0; i <= axisWidth; i++){
        if(i%5 == 0 || i % 10 == 0 ){
            cout << i;
            if(i >= 10){
                i++;
            }
        }else{
            cout << " ";
        }

    }
    cout << endl;

}

void drawCount(int value, int quantity){
    cout << setw(3) << value;
    cout << " |";
    for(int i = 0; i < quantity; i++){
        cout << "#";
    }
    cout << endl;
}

void arrayValues(int array[], int start_index, int end_index){
    int values;
    cin >> values;
    while (cin) {
        if (values < start_index || values > end_index) {
            cout << "Error: value " << values << " is out of range" << endl;
        }
        else {
            array[values-start_index]++;
        }
        cin >> values;
    }
}


void histogram(int array[], int start_index, int end_index){

    for(int i = end_index-start_index; i >= 0; i--){
        drawCount(i + start_index, array[i]);
    }

    int width = axisWidth(array, start_index, end_index);
    drawHorizontalAxis(width);
    labelHorizontalAxis(width);
}

