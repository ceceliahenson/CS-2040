#include "poly.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include <assert.h>



void initialize_polynomial(struct Polynomial *poly, char variable) {
    int i;
    for (i = 0; i < 3; i++) {
        poly->coefficients[i] = 0;
    }
    poly->variable = variable;
}

bool read_polynomial(struct Polynomial *poly, const char *readChar) {
    int poly_read = sscanf(readChar,"%d + %dx1 + %dx2", &poly->coefficients[0], &poly->coefficients[1], &poly->coefficients[2]);
    if (poly_read != 3) {
        return false;
    }
    return true;
}

int get_coefficient(struct Polynomial *poly, int index) {
    return poly->coefficients[index];
}
