#ifndef _pol_h
#define _poly_h


#include <stdbool.h>

#define MAXDEGREE 19
#define MAXTERMS (MAXDEGREE + 1)

struct Polynomial {
    int coefficients[3];
    char variable;
};

void initialize_polynomial(struct Polynomial *poly, char variable);
bool read_polynomial(struct Polynomial *poly, const char *readChar);
int get_coefficient(struct Polynomial *poly, int index);

#endif
