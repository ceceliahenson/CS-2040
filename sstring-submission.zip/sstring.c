// SString implementation

// do not add other includes
#include "sstring.h"
#include <stdio.h>

SString* make_short_string(const char *src) {
  // FIXME: implement this
  //   1. allocate space on the heap using malloc
  SString *src_pointer; 
  src_pointer = (SString *)malloc(sizeof(SString));
  
  int i = 0;
  while(*src!= '\0' && i < SHORT_STRING_LIMIT){
   //   2. set the len field to the number of characters in the source
   //      up to 10 characters
      src_pointer -> text[i++] = *src++;
  //   3. copy len characters from src to the SString value
      src_pointer -> len = i;
  }
  
  //   4. return the pointer
  return src_pointer;
}

bool short_string_equal(const SString *a, const SString *b)
{
  // FIXME: implement this
  // If the lengths are not equal, the strings are not equal
  if(a -> len != b -> len){
      return false;
  }
  // If they are equal, return whether or not all of the characters (up to that length)
  //   are the same
  if(a -> len == b -> len){
      for(int i = 0; i < a -> len; i++){
          if(a -> text[i] != b -> text[i]){
            return false;
        }
      }
  }
  return true;                 // change this!
}

// prints string to standard output, no newlines
void print_short_string(const SString *src) 
{
  for(int i = 0; i < src->len; ++i)
    // FIXME: write character i from the src's text
    printf("%c", src -> text[i]);
}

// deallocates space for the given item
void delete_short_string(SString *item)
{
  // FIXME: implement this
  free(item);

}
