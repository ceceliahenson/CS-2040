/*
 * Name: Cecelia Henson
 * Lab Name: Polynomial API (LAB 8)
 * Lab 8
 * File Desription: 
 * This poly.c file creates the implementation for the poly.h 
 * and creating a makeshift polynomial addition/subtraction API
*/
#include "poly.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include <assert.h>


/*
  *This method sets the polynomial so that all 
  * coefficents are 0 
*/
 
void initialize_polynomial(struct Polynomial *poly, char variable) {
    poly->var = variable;
    for (int i = 0; i < MAXTERMS; ++i) {
        poly->coefficent[i] = 0;
    }
}
/*
 * This method skips to the next +, -, and \0
*/
char *signIteration(char *poly_pointer) {
    while ((*poly_pointer != '+') 
        && (*poly_pointer != '-') 
        && (*poly_pointer != '\0')) {
        ++poly_pointer;
    }
    return poly_pointer;
}

/*
 * This method sets the pointer with the specific + or - 
 * as 1 and -1 
*/
int setSign(char *poly_pointer) {return (*poly_pointer == '-') ? -1 : 1;}

/*
 * This method saves the coefficient if it is within the proper
 * range of greather than 10 and smaller than MAXTERMSSS
*/
bool vaildRange(struct Polynomial *poly, int coefficent, int power, int sign){
    if (power >= 0 && power <= MAXTERMS) {
        poly->coefficent[power] = sign * coefficent;
        return true;
    } else {
        return false;
    }
}

/*
 * This method is to decouple the main read_polynomial 
 * with looping through if the poly_pointer character is 
 * + or - while calling setSign and validRange to 
 * save the coefficent and set the coefficents depending upon 
 * the + or -
*/

bool polynomialIteration(char *poly_pointer, struct Polynomial *poly) {
    int coefficent, power;
    char var;
    while((*poly_pointer == '+') || (*poly_pointer == '-')){
        int sign = setSign(poly_pointer);
        poly_pointer += 2; 
        sscanf(poly_pointer, "%d%c%d", &coefficent, &var, &power);
        if(!vaildRange(poly, coefficent, power, sign)){return false;}
        poly_pointer = signIteration(poly_pointer);
    }
    return true;
}

/*
 * This is the main read_ polynomial that I was given psuedocode for 
 * where it clears the polynomial and convers the array to read with
 * atoi to create the startString and creating the main pointer used throughout 
 * this .c and sets the first number entered to be the coefficent 
 * and calls the signIteration to go back to the "skip to next.." from
 * the psuedocode and polynomialListIteration
 * 
*/
bool read_polynomial(struct Polynomial *poly, char arrayToRead[]) {
    for(int i = 0; i < MAXTERMS; ++i){poly->coefficent[i] = 0;}
    int startString = atoi(arrayToRead);
    char *poly_pointer = arrayToRead;
    if (startString < 0){poly_pointer++;}
    poly->coefficent[0] = startString;
    poly_pointer = signIteration(poly_pointer);
    if(polynomialIteration(poly_pointer, poly)){return true;}
    else {return false;}
}

/*
 * prints out the coefficent output 
 * dependent upon if the index is negative or not 
*/
void coefficentOutput(int i, int coefficent) {
    if (i == 0) {
        if (coefficent < 0) {
            printf("-");
            printf("%d", -coefficent);
        } else {
            printf("%d", coefficent);
        }
    } else {
        if (coefficent < 0) {
            printf(" - %d", -coefficent);
        } else {
            printf(" + %d", coefficent);
        }
    }
}

/*
 * This method prints the overall polynomal with the 
 * coefficentOutput determining the sign to print
 */

int polynomialOutput(int i, const struct Polynomial* poly, int entry) {
    if (poly->coefficent[i] != 0) {
        int coefficent = poly->coefficent[i];
        if (coefficent == 0) {
            entry++;
        }
        coefficentOutput(i, coefficent); 
        if (i != 0) {
            printf("%c%d", poly->var, i);  
        }
    } else if (i == 0) {
        printf("%d", poly->coefficent[0]);
    }
    return entry;
}

/*
 * This method writes out the polynomal according to the sum_polynomial,
 * check_variables, and get_coefficent 
*/

void write_polynomial(struct Polynomial* poly) {
    int entry = 0;
    for (int i = 0; i < MAXTERMS; i++) {
        entry = polynomialOutput(i, poly, entry);
    }
    if (entry == MAXTERMS) {
        printf("%d", 0);
    }
}

/*
 * This method check variables of the polynomials first and then 
 * adds the second and third coefficents together and setting them to the 
 * overall sum polynomal of the two.
*/
bool sum_polynomial(struct Polynomial *destination, struct Polynomial *secondCoeff,struct Polynomial *thirdCoeff){
    if(check_variables(secondCoeff, thirdCoeff)){
        initialize_polynomial(destination, secondCoeff -> var);
        for(int i = 0; i < MAXTERMS; i++){
            destination->coefficent[i] = secondCoeff->coefficent[i] + thirdCoeff->coefficent[i];
        } 
        return true;
    }else{
        return false;
    }    
}

/*
 * This method checks if the variables in the first and second 
 * polynomial being passed through are the same variable and returns a true check
 * and if not returns false so that it doesn't do the sum of non matching 
 * variables.
*/

bool check_variables(struct Polynomial *poly1, struct Polynomial *poly2){
    if(poly1->var != poly2->var){
        return false;
    }
    return true;
}

/*
 * This method returns the coefficent of the term at
 * the specific parameter int power and returns the integer
 * at that power and if it is above the MAXDEGREE or less than 
 * zero it just returns 0 
 * 
*/
int get_coefficient(struct Polynomial *poly, int power) {
    if(power < 0 || power > MAXDEGREE){
        return 0;
    }else{
        return poly->coefficent[power];
    }
}
