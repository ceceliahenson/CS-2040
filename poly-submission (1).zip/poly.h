/*
 * Name: Cecelia Henson
 * Lab Name: Polynomial API (LAB 8)
 * Lab 8
*/
#ifndef _poly_h
#define _poly_h


#include <stdbool.h>

#define MAXDEGREE 19
#define MAXTERMS (MAXDEGREE + 1)


struct Polynomial {
    char var;
    int coefficent[MAXTERMS];
};

void initialize_polynomial(struct Polynomial *poly, char variable);
bool read_polynomial(struct Polynomial *poly, char arrayToRead[]);
void write_polynomial(struct Polynomial *poly);
bool check_variables(struct Polynomial *poly1, struct Polynomial *poly2);
int get_coefficient(struct Polynomial *poly, int power);
bool sum_polynomial(struct Polynomial *destination, struct Polynomial *secondCoeff,struct Polynomial *thirdCoeff);

#endif
