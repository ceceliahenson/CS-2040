//============================================================================
// Name        : pool.h
// Author      : Cecelia Henson
// Date        : 4/11/23
//============================================================================

#ifndef _pool_h
#define _pool_h

#include <iostream>
#include <string>
using namespace std;

// TODO: add comment describing Pool's responsibilities (what the class
//       provides to the rest of the system - see SE 2811 notes)

/**
 * @class Pool
 * @author student
 * @date 11/04/23
 * @file pool.h
 * @brief This class declares the methods and variables that will be 
 *        implemented in the Pool.cpp class
 */
class Pool {
public:
  Pool();
  // construct pool with a single name
  Pool(string name);
  // check if pool is empty
  bool empty();
  // add one name to pool of people to match
  void add(string name);
  // read names until reach end of file, END, or MAXNAMES items
  void readNames();
  // TODO: add methods to print matches via just a single string name 
  void printMatches(string name);
  // TODO: add method to print matches via another pool instance
  void printMatches(Pool *pool);


private:
  static constexpr int MAXNAMES = 20;
  // TODO: declare array of names using MAXNAMES and a variable to keep track of
  //       how many real names are in the array. Add other private data as needed
  string namesArray[MAXNAMES];
  int realNames;
  // TODO: add private methods here if useful
  bool checkNameMatches(string first_name, string second_name);
  void printOutput(string first_name, string second_name);
  string toLowerCase(string name);
};

// do not touch the next line
#endif
