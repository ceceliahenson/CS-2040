//============================================================================
// Name        : pool.cpp
// Author      : Cecelia Henson
// Date        : 4/11/23
//============================================================================

#include "pool.h"
#include <iostream>
#include <string>
using namespace std;

/**
 * @brief setting real names to zero
 * @return nothing
 */
Pool::Pool(){
    realNames = 0;
}

/**
 * @brief this constructs a pool with a single name
 * @param name: names inputed
 * @return nothing
 */
Pool::Pool(string name){
  // construct pool with a single name
  add(name);

}

/**
 * @brief this method checks if the pool is empty or not
 * @return if pool is empty or not
 */
bool Pool::empty() {
  bool check = false;
  if(realNames <= 0){
    check = true;
  }
  return check;
}


/**
 * @brief this method adds the name entered from user to an array of names
 *        and removes the underscore (if found) and replaces it with a space 
 * @param name: entered name from user
 */
void Pool::add(string name){
  // add one name to pool of people to match
  char underscore = '_';
  char space = ' ';
  
  for(unsigned int i = 0; i < name.size(); i++){
      if(name[i] == underscore){
          name[i] = space;
          namesArray[realNames] = name[i];
      }else{
          namesArray[realNames] = name;
          //realNames++;
      }
  }
  realNames++;
  
}

/**
 * @brief this method reads in the the names
 *        entered until the end of the file or the 
 *        MAXNAMES amount has be reached
 * 
 */
void Pool::readNames(){
  string enteredName;
  cin >> enteredName;
  while((cin && enteredName != "END")){
    if(!(realNames >= MAXNAMES)){
      add(enteredName);
      cin >> enteredName; 
    }else{
        cin >> enteredName;
    }
  }

}

/**
 * @brief this outputs the matches according to a single name
 * @param name: name inputed 
 */
void Pool::printMatches(string name){
  // outputs the matches according to a single name 
  for(int i = 0; i < realNames; i++){
          if(checkNameMatches(name, namesArray[i])){
              printOutput(name, namesArray[i]);
          }
  }
}

/**
 * @brief this method takes the input of a pool of names and matches them
 * @param pool: list of names
 */
void Pool::printMatches(Pool *pool){
  // outputs the matches according to a specific pool
  for(int i = 0; i < realNames; i++){
      pool -> printMatches(namesArray[i]);
  }
}

/**
 * @brief Function checks if there is a match 
 * @param first_name
 * @param second_name
 * @return if the names checked are a match or not 
 */
bool Pool::checkNameMatches(string first_name, string second_name){
    bool match = false;
    char space = ' ';
    
    first_name = toLowerCase(first_name);
    second_name = toLowerCase(second_name);
    
    for(unsigned int i = 0; i < first_name.length(); i++){
        if(first_name[i] != space){
            for(unsigned int j = 0; j < second_name.length(); j++){
                if(second_name[j] != space){
                    if(first_name[i] == second_name[j]){
                        match = true;
                    }
                }
            }
        }
    }
    return match;
}

/**
 * @brief This method converts the inputted names to all lower case
 *         to make the matching accurate between upper and lower case
 *         letters
 * @param name: names entered from list
 * @return names in lower case form
 */

string Pool::toLowerCase(string name){
    unsigned int i = 0;
    while(i < name.length()){;
        if(isupper(name[i])){
            name[i] = tolower(name[i]);
        }
        i++;
    }
    return name;
}

/**
 * @brief Function prints the output for the matched pairs
 * @param first_name the first name to be compared against
 * @param second_name: the second name to compare
 */
void Pool::printOutput(string first_name, string second_name){
    cout << "A perfect match for " << first_name << ": " << second_name << endl;
}
