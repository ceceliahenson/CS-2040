// league.h

#ifndef _league_h
#define _league_h

#include <map>
#include <string>
#include <list>

class Team;

class League {
public:
  League(std::string name) : _name(name) { }
  std::string name() const { return _name; }
  void register_team(Team *team);
  void record_season(const std::list<std::string> winners, 
                     const std::list<std::string> losers);
  void print_standings();
private:
  std::string _name;
  // TODO: declare a variable teams as a map from strings (using
  //       the team name) to a pointer to each Team
  
  std::map<std::string, Team*> teams;

};

#endif
