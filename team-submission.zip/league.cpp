// league.cpp - code to manage a league of teams

// Name: Cecelia Henson

// TODO: add libraries as needed
#include <map>
#include <vector>
#include <algorithm>
#include "league.h"
#include "team.h"
#include <iostream>
#include <iomanip>
#include <list>

using namespace std;

void League::register_team(Team *team) {
  // TODO: implement this to add the team to the team table
  //       You do not have to check if the entry is already present.
  teams[team -> name()] = team;
}

void League::record_season(const list<string> winners, const list<string> losers) {
  // TODO: implement this. The lists of winners and losers are in parallel, but
  //       since the order of wins and losses is not important you do not have
  //       to process the wins and losses in any particular order.
  
    for (const string& win : winners) {
        teams[win]->record_win();
    }

    for (const string& lose : losers) {
        teams[lose]->record_loss();
    }
}

bool before(const Team* a, const Team* b) {
  // TODO: implement this function by calling Team::better_than. This
  //       function will be used by the sort operation in print_standings
  return a -> better_than(b);

}

void League::print_standings() {
  vector<Team*> all_teams;
  for(auto [key,val] : teams){
    all_teams.push_back(val);
  }
  // TODO: use the sort operation in algorithm to sort all_teams by
  //       the before() function you wrote above. See
  //       https://cplusplus.com/reference/algorithm/sort/ for a discussion
  //       of sort and examples
  sort(all_teams.begin(), all_teams.end(), before);
  // print headers, set up output:
  cout << "Standings for " << _name << ":" << endl;
  cout << left << setw(25) << "Team" << "Average" << endl;
  cout << setprecision(3);

  // TODO: display the data for each team using the basic format
  //       cout << setw(25) << [team name] << [win average] << endl;
  for (const auto& team : all_teams) {
      cout << setw(25) << team->printable_name() << team->win_average() << endl;
    }
}
