// team.h

#ifndef _team_h
#define _team_h

#include <string>

class Team {
public:
  Team(std::string name, std::string city = "");
  virtual std::string name() const;
  virtual std::string printable_name() const;
  virtual bool better_than(const Team *other) const;
  virtual void record_win();
  virtual void record_loss();
  virtual int matches_played() const;
  virtual float win_average() const;
protected:
  std::string _name, _city;
  int wins;
  int losses;
};

class Mascot {
public:
  Mascot(std::string n) : _name(n) { }
  std::string name() const { return _name; }
private:
  std::string _name;
};

// DO: derive a class TeamWithMascot, from class Team
//     The constructor should set the team name and
//     store the mascot pointer. Override printable_name
//     to return the team name followed by the mascot
//     name (separate by a space)
//     Put implementations in team.cpp
class TeamWithMascot: public Team{
public: 
    TeamWithMascot(std::string name, Mascot *mascot);
    std::string printable_name() const override;
    Mascot *mascotPointer;
};
#endif
