// team.cpp

// TODO: add libraries as needed
#include "team.h"
#include <iostream>


using namespace std;

Team::Team(string name, string city) : _name(name), _city(city) { 
  wins = losses = 0;
}

string Team::name() const {
  return _name;
}

string Team::printable_name() const {
  return _city + " " + _name;
}

// TODO: implement better_than
// if both teams have played games, use the win average
// if one team has played a game and the other not, pick the team
//   that has played a game
// when there is a tie (that is, either neither team has played
//   a game or the win averages are within 1e-4 of each other), 
//   use printable_name as a tie-breake with it sorted alphabetically for each team
bool Team::better_than(const Team *other) const {
    // if both teams have played games, use the win average
    if (matches_played() > 0 && other->matches_played() > 0) {
        float aAverage = win_average();
        float bAverage = other->win_average();
        if (abs(aAverage - bAverage) > 1e-4) {
            return aAverage > bAverage;
        }
    } 
    // if one team has played a game and the other not, pick the team
    //   that has played a game
    else if (matches_played() > 0) {
        return true;
    } else if (other->matches_played() > 0) {
        return false;
    }
    //printable_name as a tie-breake with it sorted alphabetically for each team
    return printable_name() < other->printable_name();
}


void Team::record_win() { ++wins; }

void Team::record_loss() { ++losses; }

int Team::matches_played() const {
  return wins + losses;
}

float Team::win_average() const {
  if ( wins + losses == 0 )
    return 0.0;
  else
    return float(wins) / float(wins + losses);
}

// TODO: implement TeamWithMascot methods here

//TODO: The constructor should set the team name and
//      store the mascot pointer.

TeamWithMascot::TeamWithMascot(string name, Mascot* mascot) : Team(name, ""), mascotPointer(mascot) {
}

//TODO: Override printable_name
//      to return the team name followed by the mascot
//      name (separate by a space)
std::string TeamWithMascot::printable_name() const{
    return name() + " " + mascotPointer->name();
}
